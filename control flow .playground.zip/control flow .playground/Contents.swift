import UIKit
let Maxtime = 100
// i am using 100 as the amount of time given
for Timer in 0...MaxTime
// 0 is were the timer is going to start
{
print ("\(Timer)seconds")
    if Timer == MaxTime{
        print("TIME IS UP")
        // The time is up and will give a notice of that
    }
}
